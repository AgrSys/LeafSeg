import cv2
import numpy as np
import os

# 输入和输出目录
input_dir1 = "/datadisk/yang/grap_dataset/test_dataset/raw"
input_dir2 = "/datadisk/yang/grap_dataset/test_dataset/sam"
output_dir = "/datadisk/yang/grap_dataset/test_dataset/mask_sam"

# 列出两个输入目录中的所有文件
files1 = os.listdir(input_dir1)
files2 = os.listdir(input_dir2)

# 创建一个字典，将文件名（不包括扩展名）映射到完整文件路径
files_dict1 = {f.split(".")[0]: f for f in files1}
files_dict2 = {f.split(".")[0]: f for f in files2}

# 对于每一个在两个文件夹中都存在的文件id
for file_id in set(files_dict1.keys()).intersection(files_dict2.keys()):
    # 获取对应的文件名
    file1 = files_dict1[file_id]
    file2 = files_dict2[file_id]

    # 读取原始图片和被扣出的图片，以彩色方式读取, RGB, alpha pixel are converted to black pixel
    image1 = cv2.imread(os.path.join(input_dir1, file1))
    image2 = cv2.imread(os.path.join(input_dir2, file2))

    # 使用模板匹配找到被扣出的位置
    result = cv2.matchTemplate(image1, image2, cv2.TM_CCOEFF_NORMED)
    _, _, _, max_loc = cv2.minMaxLoc(result)
    top_left = max_loc
    bottom_right = (top_left[0] + image2.shape[1], top_left[1] + image2.shape[0])

    # 创建一个全黑的图片，尺寸和原始图片一样
    mask = np.zeros_like(image1)

    # 遍历image2的每个像素
    for i in range(image2.shape[0]):
        for j in range(image2.shape[1]):
            # 如果
            if image2[i, j, 0] == 0 and image2[i, j, 1] == 0 and image2[i, j, 2] == 0:
                # 在mask的对应位置填充白色
                mask[top_left[1] + i, top_left[0] + j] = (0, 0, 0)
            else:
                mask[top_left[1] + i, top_left[0] + j] = (255, 255, 255)

    # 保存处理后的图片
    cv2.imwrite(os.path.join(output_dir, file_id + ".png"), mask)
