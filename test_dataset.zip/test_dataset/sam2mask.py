import cv2
import numpy as np

# 读取原始图片和被扣出的图片，以彩色方式读取
image1 = cv2.imread('/datadisk/yang/grap_dataset/test_dataset/raw/15.JPG')
image2 = cv2.imread('/datadisk/yang/grap_dataset/test_dataset/sam/15.png')
# 使用模板匹配找到被扣出的位置
result = cv2.matchTemplate(image1, image2, cv2.TM_CCOEFF_NORMED)
_, _, _, max_loc = cv2.minMaxLoc(result)
top_left = max_loc
bottom_right = (top_left[0] + image2.shape[1], top_left[1] + image2.shape[0])

# 创建一个全黑的图片，尺寸和原始图片一样，注意这里使用3通道以表示RGB颜色
mask = np.zeros_like(image1)


# 遍历image2的每个像素
for i in range(image2.shape[0]):
    for j in range(image2.shape[1]):
        # 如果alpha通道的值不等于0（即不透明）
        if image2[i, j, 0] == 0 and image2[i, j, 1] == 0 and image2[i, j, 2] == 0:
            # 在mask的对应位置填充白色
            mask[top_left[1]+i, top_left[0]+j] = (0, 0, 0)
        else: 
            mask[top_left[1]+i, top_left[0]+j] = (255,255,255)

# 保存处理后的图片
cv2.imwrite('output5.jpg', mask)
