import os
import json
import numpy as np
from PIL import Image
import cv2

# Define your directory here
json_dir = "/datadisk/yang/grap_dataset/test_dataset/json2"
output_dir = "/datadisk/yang/grap_dataset/test_dataset/mask2"

# Ensure the output directory exists
os.makedirs(output_dir, exist_ok=True)

# Define the label to integer mapping
label_mapping = {
    "_background_": 0,
    "leaf": 255,
}

# Define the order of the labels
label_order = ["leaf", "_background_"]

# Loop over all files in the JSON directory
for filename in os.listdir(json_dir):
    if filename.endswith(".json"):
        # Open the JSON file
        with open(os.path.join(json_dir, filename)) as f:
            data = json.load(f)

            # Extract image dimensions
            img_height = data["imageHeight"]
            img_width = data["imageWidth"]

            # Create an empty mask
            mask = np.zeros([img_height, img_width], dtype=np.uint8)

            # Loop over all labels in the specified order
            for label in label_order:
                # Find the shapes with the current label
                shapes = [shape for shape in data["shapes"] if shape["label"] == label]

                # Loop over all shapes with the current label
                for shape in shapes:
                    points = shape["points"]

                    # Convert the points to a 2D numpy array
                    points_np = np.array(points, dtype=np.int32)

                    # Draw the shape on the mask with corresponding value
                    cv2.fillPoly(mask, [points_np], label_mapping[label])

            # Create a PIL Image from the numpy array
            mask_img = Image.fromarray(mask)

            # Save the image
            mask_img.save(
                os.path.join(output_dir, f"{os.path.splitext(filename)[0]}.png")
            )
